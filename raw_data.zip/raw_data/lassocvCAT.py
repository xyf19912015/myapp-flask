# -*- coding: utf-8 -*-
"""
Created on Thu Jan  2 16:33:00 2025

@author: Administrator
"""
# 导入必要的库
from catboost import CatBoostClassifier
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, StratifiedKFold
from sklearn.metrics import (confusion_matrix, roc_curve, roc_auc_score, classification_report, auc)
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso
from scipy import stats
import shap

# 设置绘图风格
plt.style.use('seaborn-darkgrid')
random_state = 42

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)
y = data['PCAA']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 过采样处理不平衡数据
smote = SMOTE(sampling_strategy=0.5, random_state=random_state)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# 训练集和测试集分割（使用分层抽样）
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=random_state,stratify=y_resampled)

# 使用LassoCV进行特征选择
lasso_cv = LassoCV(alphas=np.logspace(-4, 1, 50), cv=5, max_iter=10000, random_state=random_state)
lasso_cv.fit(X_train, y_train)

# 获取最佳alpha值
best_alpha = lasso_cv.alpha_
print(f"Optimal alpha value: {best_alpha}")

# 使用最佳alpha值拟合Lasso模型
lasso_model = Lasso(alpha=best_alpha)
lasso_model.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_model.coef_

# 可视化Lasso回归系数（柱状图）
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 8))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title(f'Lasso Regression Coefficients (alpha={best_alpha})')
plt.xlabel('Coefficient')
plt.ylabel('Feature')
plt.grid(axis='x')  # 添加竖直网格线
plt.tight_layout()
plt.show()

# 手动计算Lasso回归系数路径
alphas = np.logspace(-4, 1, 50)
coefs = []  # 用于存储每个alpha值对应的系数
for alpha in alphas:
    lasso_temp = Lasso(alpha=alpha)
    lasso_temp.fit(X_train, y_train)
    coefs.append(lasso_temp.coef_)

# 将系数列表转换为NumPy数组，以便后续绘图
coefs = np.array(coefs)

# 绘制Lasso回归系数路径折线图
plt.figure(figsize=(10, 8))
for i in range(coefs.shape[1]):  # 对每个特征绘图
    plt.plot(alphas, coefs[:, i], label=feature_names[i])
plt.axvline(best_alpha, linestyle='--', color='k', label='Optimal alpha')
plt.xscale('log')
plt.xlabel('Alpha')
plt.ylabel('Coefficient')
plt.title('Lasso Paths')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize='small')
plt.grid(axis='x')  # 添加竖直网格线
plt.tight_layout()
plt.show()

# 使用Lasso回归系数筛选特征
selected_features = coefs_df['Feature'].values
selected_indices = [list(feature_names).index(feat) for feat in selected_features]
X_train_selected = X_train[:, selected_indices]
X_test_selected = X_test[:, selected_indices]

print(f"Number of selected features at alpha={best_alpha}: {len(selected_features)}")

# 训练 CatBoost 模型
catboost_classifier = CatBoostClassifier(random_seed=random_state, verbose=0)

# 定义超参数网格
param_grid = {
    'iterations': [200],
    'learning_rate': [0.1],
    'depth': [5],
    'l2_leaf_reg': [1],
    'border_count': [32]
}

# 使用 GridSearchCV 进行参数调优
grid_search = GridSearchCV(estimator=catboost_classifier, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)

# 获取最佳模型
best_catboost = grid_search.best_estimator_
print(grid_search.best_estimator_)

# 预测和评估
y_pred_train = best_catboost.predict(X_train_selected)
y_pred_test = best_catboost.predict(X_test_selected)

# 计算混淆矩阵
conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)

print("Training Confusion Matrix:")
print(conf_matrix_train)
print("Testing Confusion Matrix:")
print(conf_matrix_test)


# 计算并绘制ROC曲线
y_pred_proba_test = best_catboost.predict_proba(X_test_selected)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)

# 绘制ROC曲线
plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.legend(loc='lower right')
plt.title('CatBoost ROC Curve', fontweight='bold', fontsize=14)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN)
    specificity = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    PLR = sensitivity / (1 - specificity)
    NLR = (1 - sensitivity) / specificity
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

# 计算测试集性能指标
acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Performance Metrics:")
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证得分
scores = cross_val_score(best_catboost, X_train_selected, y_train, cv=5)
print("Cross-Validation Scores:")
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 计算置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出 F1 值等评估报告
print("Classification Report:")
print(classification_report(y_test, y_pred_test))

# 进一步进行交叉验证 ROC 曲线绘制
cv = StratifiedKFold(n_splits=5)
tprs = []
aucs = []
mean_fpr = np.linspace(0, 1, 100)

plt.figure(figsize=(10, 8))

for i, (train_idx, test_idx) in enumerate(cv.split(X_train_selected, y_train)):
    best_catboost.fit(X_train_selected[train_idx], y_train.iloc[train_idx])
    y_pred_proba = best_catboost.predict_proba(X_train_selected[test_idx])[:, 1]
    fpr, tpr, _ = roc_curve(y_train.iloc[test_idx], y_pred_proba)
    tprs.append(np.interp(mean_fpr, fpr, tpr))  # 插值
    tprs[-1][0] = 0.0
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
    plt.plot(fpr, tpr, lw=1, alpha=0.3, label='ROC fold %d (AUC = %0.4f)' % (i, roc_auc))

# 绘制对角线
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', alpha=.8)

# 绘制均值ROC曲线
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(aucs)
plt.plot(mean_fpr, mean_tpr, color='b',
         label=r'Mean ROC (AUC = %0.4f $\pm$ %0.4f)' % (mean_auc, std_auc),
         lw=2, alpha=.8)

# 填充标准差区域
std_tpr = np.std(tprs, axis=0)
tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,
                 label=r'$\pm$ 1 std. dev.')

# 绘制图形标签
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('Internal Validation ROC Curve', fontweight='bold', fontsize=16)
plt.legend(loc="lower right", frameon=True)
plt.show()






























# Convert arrays back to DataFrame for interpretability with correct column names after feature selection
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)




# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_catboost, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# SHAP总结图
shap.summary_plot(shap_values, X_test_selected_df, cmap="plasma")
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar', cmap="plasma")

# SHAP依赖图
for name in X_train_selected_df.columns:
    shap.dependence_plot(name, shap_values.values, X_test_selected_df, cmap="plasma")

# 计算平均绝对SHAP值
import matplotlib.pyplot as plt
import shap

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# 使用 gridspec 创建共享 y 轴的子图
fig = plt.figure(figsize=(30, 8))
# gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])
# 调整 width_ratios 以让直方图更小
gs = fig.add_gridspec(1, 2, width_ratios=[2, 1]) 
# 创建第一个子图 (点图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False,cmap="plasma")
ax1.set_title("SHAP Summary Plot (Dot)")

# 创建第二个子图 (柱状图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values, X_test_selected_df, plot_type="bar", show=False,cmap="plasma")
ax2.set_title("SHAP Summary Plot (Bar)")

# 调整子图之间的间距
plt.subplots_adjust(wspace=0.3)  # 根据需要调整 wspace 来增加或减少间距
# 获取柱状图的条
bars = ax2.patches

# 设置每个条的颜色为秋叶金
goldenrod = '#DAA520'  # 秋叶金的十六进制代码
for bar in bars:
    bar.set_facecolor(goldenrod)
# 隐藏第二个子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整布局
plt.tight_layout()
plt.show()     
    
import numpy as np
import shap

# 选择多个样本进行SHAP瀑布图和力图展示
num_samples_to_show = 1  # 要显示的样本数量

for sample_index in range(num_samples_to_show):
    # SHAP瀑布图
    plt.figure(figsize=(10, 6))
    shap.waterfall_plot(shap_values[sample_index], max_display=10)
    plt.title(f"SHAP Waterfall Plot for sample {sample_index}")
    plt.show()
    
    # SHAP力图 (将特征值格式化为4位小数)
    formatted_features = X_test_selected_df.iloc[sample_index].copy()
    formatted_features = formatted_features.apply(lambda x: f"{x:.4f}")  # 格式化为四位小数

    plt.figure(figsize=(10, 6))
    shap.force_plot(
        explainer.expected_value,
        shap_values.values[sample_index],
        formatted_features,  # 使用格式化后的特征
        matplotlib=True
    )
    plt.title(f"SHAP Force Plot for sample {sample_index} (Formatted)")
    plt.show()   
    
    
# 计算约登指数和最优阈值
def calculate_youden_index(y_true, y_proba):
    from sklearn.metrics import roc_curve
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    youden_index = tpr - fpr
    best_threshold = thresholds[np.argmax(youden_index)]
    best_youden_index = np.max(youden_index)
    return best_threshold, best_youden_index

# 计算预测概率
y_pred_proba_test = best_catboost.predict_proba(X_test_selected)[:, 1]

# 计算最佳阈值和约登指数
best_threshold, best_youden_index = calculate_youden_index(y_test, y_pred_proba_test)
print(f"Best Threshold: {best_threshold}")
print(f"Youden's Index: {best_youden_index}")
    

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_curve

# 计算约登指数和最优阈值
def calculate_youden_index(y_true, y_proba):
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    youden_index = tpr - fpr
    best_threshold = thresholds[np.argmax(youden_index)]
    best_youden_index = np.max(youden_index)
    return best_threshold, best_youden_index

# 使用5折交叉验证来计算最佳阈值
def cross_validated_youden_index(X, y, model, cv=5):
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=random_state)
    thresholds = []
    youden_indices = []
    
    for train_index, test_index in skf.split(X, y):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        
        model.fit(X_train, y_train)
        y_proba = model.predict_proba(X_test)[:, 1]
        
        best_threshold, best_youden_index = calculate_youden_index(y_test, y_proba)
        thresholds.append(best_threshold)
        youden_indices.append(best_youden_index)
    
    return np.mean(thresholds), np.mean(youden_indices)

# 在计算预测概率之前要训练好模型
# 假设你已经训练了best_catboost并且X_test_selected和y_test是相应的测试数据和标签

# 计算最佳阈值和约登指数
best_threshold, best_youden_index = cross_validated_youden_index(X_resampled, y_resampled, best_catboost)
print(f"Best Threshold: {best_threshold}")
print(f"Youden's Index: {best_youden_index}")

    
    
    