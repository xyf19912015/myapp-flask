# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 16:37:20 2024

@author: Administrator
"""

# 导入必要的库
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import ADASYN  # 使用 ADASYN 替代 SMOTE
from sklearn.linear_model import LassoCV, Lasso, LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, StratifiedKFold
from sklearn.metrics import (confusion_matrix, roc_curve, roc_auc_score, classification_report,
                             auc, precision_recall_curve, f1_score, precision_score, recall_score)
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from catboost import CatBoostClassifier
from scipy import stats
import shap  # 导入SHAP库

# 设置绘图风格
sns.set_palette("husl")
plt.style.use('seaborn-darkgrid')
# 设置随机种子
random_state = 42

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)  # 特征
y = data['PCAA']  # 目标变量

# **修正：训练集测试集分割需要在标准化操作之前进行**
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=random_state, stratify=y
)

# **修正：标准化仅使用训练集的均值和标准差**
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)  # 仅用训练集的均值和标准差进行标准化
X_test = scaler.transform(X_test)       # 使用训练集的均值和标准差标准化测试集

# **使用 ADASYN 替代 SMOTE**
adasyn = ADASYN(sampling_strategy=0.5, random_state=random_state)
X_train_resampled, y_train_resampled = adasyn.fit_resample(X_train, y_train)

# 使用LassoCV进行特征选择
lasso_cv = LassoCV(alphas=np.logspace(-4, 1, 50), cv=10, max_iter=10000, random_state=random_state)
lasso_cv.fit(X_train_resampled, y_train_resampled)

# 找到最佳alpha值
best_alpha = lasso_cv.alpha_
print(f"Optimal alpha value: {best_alpha}")

# 使用最佳alpha值拟合Lasso模型
lasso_model = Lasso(alpha=best_alpha)
lasso_model.fit(X_train_resampled, y_train_resampled)

# 获取Lasso回归系数
lasso_coefs = lasso_model.coef_

# 可视化Lasso回归非零系数
feature_names = X.columns.tolist()  # 转换为列表
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数非零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 8))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title(f'Lasso Regression Coefficients (alpha={best_alpha})', fontsize=16)
plt.xlabel('Coefficient')
plt.ylabel('Feature')
plt.tight_layout()
plt.show()

# 手动计算Lasso回归系数路径
alphas = np.logspace(-4, 1, 50)
coefs = []  # 用于存储每个alpha值对应的系数
for alpha in alphas:
    lasso_temp = Lasso(alpha=alpha)
    lasso_temp.fit(X_train, y_train)
    coefs.append(lasso_temp.coef_)

# 将系数列表转换为NumPy数组，以便后续绘图
coefs = np.array(coefs)

# 绘制Lasso回归系数路径折线图
plt.figure(figsize=(10, 8))
for i in range(coefs.shape[1]):  # 对每个特征绘图
    plt.plot(alphas, coefs[:, i], label=feature_names[i])
plt.axvline(best_alpha, linestyle='--', color='k', label='Optimal alpha')
plt.xscale('log')
plt.xlabel('Alpha')
plt.ylabel('Coefficient')
plt.title('Lasso Paths', fontsize=16)
# 将图例放在折线图内的右上方
plt.legend(bbox_to_anchor=(1, 1), loc='upper right', fontsize='small', frameon=True)
plt.tight_layout()
plt.grid(axis='y')
plt.show()

# 通过Lasso筛选特征
selected_features = coefs_df['Feature'].values
selected_indices = [feature_names.index(feat) for feat in selected_features]  # 直接使用列表查找
X_train_selected = X_train_resampled[:, selected_indices]
X_test_selected = X_test[:, selected_indices]

print(f"Number of selected features at alpha={best_alpha}: {len(selected_features)}")
print("Shape of X_train_selected:", X_train_selected.shape)
print("Shape of y_train_resampled:", y_train_resampled.shape)

# 模型初始化
models = {
    'XGBoost': XGBClassifier(random_state=random_state, eval_metric='logloss'),
    'CatBoost': CatBoostClassifier(random_seed=random_state, verbose=0),
    'LR': LogisticRegression(random_state=random_state, max_iter=1000),
    'RF': RandomForestClassifier(random_state=random_state),
    'DT': DecisionTreeClassifier(random_state=random_state),
    'AdaBoost': AdaBoostClassifier(random_state=random_state),
    'GB': GradientBoostingClassifier(random_state=random_state),
    'SVM': SVC(kernel='linear', probability=True, random_state=random_state),
    'GNB': GaussianNB(),
    'MLP': MLPClassifier(random_state=random_state, max_iter=1000)
}

param_grids = {
   'XGBoost': {
        'n_estimators': [400],                     # 尝试不同的树的数量
        'learning_rate': [0.01],                   # 学习率范围
        'max_depth': [6],                                # 树的深度范围
        'min_child_weight': [1],                            # 最小子权重范围
        'gamma': [0.1],                                # γ的范围，从无到适度控制复杂度
        'subsample': [1.0],                             # 样本比例
        'colsample_bytree': [0.5],                      # 特征选择比例
        'reg_alpha': [0.01],                              # L1正则化
        'reg_lambda': [0.1]                                 # L2正则化
    },
    'CatBoost': {
        'iterations': [200],                 # 尝试不同的迭代次数
        'learning_rate': [0.1],                    # 保持不变
        'depth': [8],                          # 修改树的深度
        'l2_leaf_reg': [1],                    # 尝试不同的L2正则化值
        'border_count': [32]                       # 保持不变
    },
    'LR': {
        'C': [1.0],                          # 尝试更大的常数以便于正则化
        'penalty': ['l2'],                        # 保持不变
        'solver': ['lbfgs']                       # 保持不变
    },
    'RF': {
        'n_estimators': [200],               # 尝试降低树的数量以加速计算
        'max_depth': [None],                  # 增加最大深度
        'min_samples_split': [2],              # 尝试不同的分割最小样本数
        'min_samples_leaf': [1],               # 尝试不同的最小样本数以防止过拟合
        'max_features': ['sqrt']         # 尝试不同的特征选择方式
    },
    'DT': {
        'max_depth': [5],                     # 尝试不同的最大深度
        'min_samples_split': [2],              # 尝试不同的最小分割样本数
        'min_samples_leaf': [2],               # 尝试不同的最小叶子样本数
        'criterion': ['entropy']          # 增加不同的分裂标准
    },
    'AdaBoost': {
        'n_estimators': [50],                # 尝试不同的基模型数量
        'learning_rate': [0.5]               # 尝试不同的学习率
    },
    'GB': {
        'n_estimators': [200],               # 尝试不同的迭代次数
        'learning_rate': [0.1],               # 保持不变
        'max_depth': [5],                      # 尝试不同的深度
        'min_samples_split': [2]               # 尝试不同的最小分割样本数
    },
    'SVM': {
        'C': [1.0],                          # 尝试不同的常数
        'kernel': ['rbf']               # 增加非线性内核
    },
    'GNB': {
        'var_smoothing': [1e-09]                  # 保持不变
    },
    'MLP': {
        'hidden_layer_sizes': [(100, 50)],  # 增加不同的隐藏层结构
        'activation': ['relu'],           # 增加不同的激活函数
        'solver': ['adam'],                        # 保持不变
        'alpha': [0.01]                    # 尝试不同的正则化参数
    }
}
# 后续部分保持不变...

# 继续进行模型训练、评估等操作...



# 存储模型的ROC曲线和PR曲线数据
roc_data = {}
pr_data = {}

# 定义交叉验证策略
cv_strategy = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)

# 存储模型性能
model_performance = {}
best_params = {}
prob_predictions = {}
evaluation_metrics = {
    'Model': [], 'Accuracy': [], 'Sensitivity (Recall)': [], 'Specificity': [],
    'Positive Predictive Value (Precision)': [], 'Negative Predictive Value': [],
    'Positive Likelihood Ratio': [], 'Negative Likelihood Ratio': [], 'F1 Score': [],
    'Precision': [], 'Recall': [], 'ROC AUC (Test)': []
}

# 转换为NumPy数组以避免索引问题
y_train_resampled_np = y_train_resampled.to_numpy() if isinstance(y_train_resampled, pd.Series) else y_train_resampled

# 遍历每个模型进行训练、预测和评估
for model_name, model in models.items():
    print(f"\nTraining and evaluating {model_name}...")
    
    param_grid = param_grids.get(model_name, {})
    grid_search = GridSearchCV(
        estimator=model, param_grid=param_grid, cv=cv_strategy, scoring='roc_auc', n_jobs=-1, verbose=0
    )
    grid_search.fit(X_train_selected, y_train_resampled_np)
    
    best_model = grid_search.best_estimator_
    print(f"Best parameters for {model_name}: {grid_search.best_params_}")
    
    cv_scores = cross_val_score(best_model, X_train_selected, y_train_resampled_np, cv=cv_strategy, scoring='accuracy', n_jobs=-1)
    avg_accuracy = cv_scores.mean()
    confidence_interval = stats.t.interval(0.95, len(cv_scores)-1, loc=avg_accuracy, scale=stats.sem(cv_scores))
    print(f"Average Accuracy: {avg_accuracy:.4f} (95% confidence interval: {confidence_interval})")
    
    best_params[model_name] = grid_search.best_params_
    
    y_pred_test = best_model.predict(X_test_selected)
    conf_matrix_test = confusion_matrix(y_test, y_pred_test)
    print(f"Confusion Matrix for {model_name} on Test Set:\n{conf_matrix_test}")
    print(f"Classification Report for {model_name}:\n{classification_report(y_test, y_pred_test)}")
    
    if hasattr(best_model, "predict_proba"):
        y_pred_proba_test = best_model.predict_proba(X_test_selected)[:, 1]
        y_pred_proba_train = best_model.predict_proba(X_train_selected)[:, 1]
    elif hasattr(best_model, "decision_function"):
        y_pred_proba_test = best_model.decision_function(X_test_selected)
        y_pred_proba_train = best_model.decision_function(X_train_selected)
    else:
        y_pred_proba_test = y_pred_test
        y_pred_proba_train = best_model.predict(X_train_selected)
    
    prob_predictions[model_name] = y_pred_proba_test
    
    fpr_test, tpr_test, _ = roc_curve(y_test, y_pred_proba_test)
    roc_auc_test = roc_auc_score(y_test, y_pred_proba_test)
    fpr_train, tpr_train, _ = roc_curve(y_train_resampled_np, y_pred_proba_train)
    roc_auc_train = roc_auc_score(y_train_resampled_np, y_pred_proba_train)
    
    roc_data[model_name] = {
        'fpr_train': fpr_train, 'tpr_train': tpr_train, 'roc_auc_train': roc_auc_train,
        'fpr_test': fpr_test, 'tpr_test': tpr_test, 'roc_auc_test': roc_auc_test
    }
    
    precision_test, recall_test, _ = precision_recall_curve(y_test, y_pred_proba_test)
    pr_auc_test = auc(recall_test, precision_test)
    precision_train, recall_train, _ = precision_recall_curve(y_train_resampled_np, y_pred_proba_train)
    pr_auc_train = auc(recall_train, precision_train)
    
    pr_data[model_name] = {
        'precision_train': precision_train, 'recall_train': recall_train, 'pr_auc_train': pr_auc_train,
        'precision_test': precision_test, 'recall_test': recall_test, 'pr_auc_test': pr_auc_test
    }
    
    acc = (conf_matrix_test[0,0] + conf_matrix_test[1,1]) / np.sum(conf_matrix_test)
    sens = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[1,0]) if (conf_matrix_test[1,1] + conf_matrix_test[1,0]) != 0 else 0
    spec = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[0,1]) if (conf_matrix_test[0,0] + conf_matrix_test[0,1]) != 0 else 0
    ppv = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[0,1]) if (conf_matrix_test[1,1] + conf_matrix_test[0,1]) != 0 else 0
    npv = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[1,0]) if (conf_matrix_test[0,0] + conf_matrix_test[1,0]) != 0 else 0
    plr = sens / (1 - spec) if (1 - spec) != 0 else 0
    nlr = (1 - sens) / spec if spec != 0 else 0
    f1 = f1_score(y_test, y_pred_test)
    precision = precision_score(y_test, y_pred_test)
    recall = recall_score(y_test, y_pred_test)
    
    print(f"{model_name} Performance Metrics:")
    print(f"Accuracy: {acc:.4f}")
    print(f"Sensitivity (Recall): {sens:.4f}")
    print(f"Specificity: {spec:.4f}")
    print(f"Positive Predictive Value (Precision): {ppv:.4f}")
    print(f"Negative Predictive Value: {npv:.4f}")
    print(f"Positive Likelihood Ratio: {plr:.4f}")
    print(f"Negative Likelihood Ratio: {nlr:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    
    cv_scores = cross_val_score(best_model, X_train_selected, y_train_resampled_np, cv=cv_strategy, scoring='roc_auc', n_jobs=-1)
    print(f"Cross-Validation ROC AUC for {model_name}: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    
    confidence_interval = stats.t.interval(0.95, len(cv_scores)-1, loc=np.mean(cv_scores), scale=stats.sem(cv_scores))
    print(f"95% Confidence Interval for {model_name}: {confidence_interval}")
    
    model_performance[model_name] = {'roc_auc_test': roc_auc_test, ' Perecisf1_score': f1, 'precision': precision, 'recall': recall}
    
    evaluation_metrics['Model'].append(model_name)
    evaluation_metrics['Accuracy'].append(acc)
    evaluation_metrics['Sensitivity (Recall)'].append(sens)
    evaluation_metrics['Specificity'].append(spec)
    evaluation_metrics['Positive Predictive Value (Precision)'].append(ppv)
    evaluation_metrics['Negative Predictive Value'].append(npv)
    evaluation_metrics['Positive Likelihood Ratio'].append(plr)
    evaluation_metrics['Negative Likelihood Ratio'].append(nlr)
    evaluation_metrics['F1 Score'].append(f1)
    evaluation_metrics['Precision'].append(precision)
    evaluation_metrics['Recall'].append(recall)
    evaluation_metrics['ROC AUC (Test)'].append(roc_auc_test)

# 创建并保存最佳参数和评估指标的数据框
best_params_df = pd.DataFrame.from_dict(best_params, orient='index').reset_index().rename(columns={'index': 'Model'})
print("\nBest Parameters for Each Model:")
print(best_params_df)
best_params_df.to_csv("best_parameters.csv", index=False, encoding='utf-8-sig')
print("Best parameters have been saved to 'best_parameters.csv'.")

evaluation_metrics_df = pd.DataFrame(evaluation_metrics)
print("\nEvaluation Metrics for Each Model:")
print(evaluation_metrics_df)
evaluation_metrics_df.to_csv("evaluation_metrics.csv", index=False, encoding='utf-8-sig')
print("Evaluation metrics have been saved to 'evaluation_metrics.csv'.")


# 绘制平均 ROC AUC 曲线
mean_roc_auc = [data['roc_auc_test'] for data in roc_data.values()]
# 将最高的模型放在顶部
mean_model_names = list(roc_data.keys())

plt.figure(figsize=(12, 8))
bars = plt.barh(mean_model_names, mean_roc_auc, color='skyblue')
plt.axvline(x=0.5, color='r', linestyle='--', label='Random Guess')

plt.title('Mean ROC AUC for Different Models', fontsize=16)
plt.xlabel('ROC AUC', fontsize=14)
plt.ylabel('Models', fontsize=14)
plt.xlim(0, 1)
plt.legend()

# 添加数据标签
for bar in bars:
    width = bar.get_width()
    plt.text(width, bar.get_y() + bar.get_height()/2, f'{width:.4f}', va='center')

plt.tight_layout()
plt.show()












# 绘制ROC曲线（测试集）
plt.figure(figsize=(10, 8))
for model_name, data_roc in roc_data.items():
    plt.plot(data_roc['fpr_test'], data_roc['tpr_test'],
             label=f'{model_name} (AUC = {data_roc["roc_auc_test"]:.4f})')
plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
plt.title('ROC Curves for Multiple Models (Test Set)', fontweight='bold', fontsize=16)
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.legend(loc='lower right', fontsize=12, frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()

# 绘制PR曲线（测试集）
plt.figure(figsize=(10, 8))
for model_name, data_pr in pr_data.items():
    plt.plot(data_pr['recall_test'], data_pr['precision_test'],
             label=f'{model_name} (PR AUC = {data_pr["pr_auc_test"]:.4f})')
plt.title('Precision-Recall Curves for Multiple Models (Test Set)', fontweight='bold', fontsize=16)
plt.xlabel('Recall', fontsize=14)
plt.ylabel('Precision', fontsize=14)
plt.legend(loc='lower left', fontsize=12, frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()

# 打印 ROC AUC 和 PR AUC
print("\nROC AUC Results:")
for model_name, data_roc in roc_data.items():
    print(f"{model_name}: {data_roc['roc_auc_test']:.4f}")

print("\nPR AUC Results:")
for model_name, data_pr in pr_data.items():
    print(f"{model_name}: {data_pr['pr_auc_test']:.4f}")



# 绘制特征重要性（以最佳模型为例）
best_model_name = max(model_performance, key=lambda x: model_performance[x]['roc_auc_test'])
best_model = models[best_model_name]
best_model.fit(X_train_selected, y_train_resampled_np)

plt.figure(figsize=(10, 8))
if hasattr(best_model, 'feature_importances_'):
    importances = best_model.feature_importances_
    indices = np.argsort(importances)[::-1]
    sorted_features = selected_features[indices]
    sorted_importances = importances[indices]
    sns.barplot(x=sorted_importances, y=sorted_features)
    plt.title(f'Feature Importances ({best_model_name})')
    plt.xlabel('Importance')
    plt.ylabel('Feature')
    plt.tight_layout()
    plt.show()
else:
    print(f"{best_model_name} does not have feature_importances_ attribute.")

# 定义净收益计算函数
def calculate_net_benefit(y_true, y_probs, thresholds):
    net_benefits = []
    for threshold in thresholds:
        y_pred = (y_probs >= threshold).astype(int)
        TP = np.sum((y_pred == 1) & (y_true == 1))
        FP = np.sum((y_pred == 1) & (y_true == 0))
        N = len(y_true)
        net_benefit = (TP / N) - (FP / N) * (threshold / (1 - threshold)) if N > 0 and (1 - threshold) != 0 else 0
        net_benefits.append(net_benefit)
    return net_benefits

# 计算并绘制DCA曲线
thresholds = np.linspace(0.1, 0.9, 100)
net_benefit_data = {}
best_thresholds = {}

for model_name, probs in prob_predictions.items():
    net_benefit = calculate_net_benefit(y_test.values, probs, thresholds)
    net_benefit_data[model_name] = net_benefit
    max_net_benefit = max(net_benefit)
    best_threshold = thresholds[np.argmax(net_benefit)]
    best_thresholds[model_name] = (best_threshold, max_net_benefit)
    print(f"{model_name} 最佳阈值: {best_threshold:.2f}, 最大净收益: {max_net_benefit:.4f}")

baseline_benefit = np.mean(y_test)
plt.figure(figsize=(10, 8))
for model_name, net_benefit in net_benefit_data.items():
    plt.plot(thresholds, net_benefit, label=model_name)
plt.plot(thresholds, [baseline_benefit] * len(thresholds), 'k--', label='Hypothetical All Positive')
plt.title('Decision Curve Analysis (DCA)', fontweight='bold', fontsize=16)
plt.xlabel('Threshold Probability', fontsize=14)
plt.ylabel('Net Benefit', fontsize=14)
plt.legend(loc='lower left', fontsize=12, frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()

# 交叉验证ROC曲线
cv = StratifiedKFold(n_splits=5)
tprs = []
aucs = []
mean_fpr = np.linspace(0, 1, 100)

plt.figure(figsize=(10, 8))
for i, (train_idx, test_idx) in enumerate(cv.split(X_train_selected, y_train_resampled_np)):
    best_model.fit(X_train_selected[train_idx], y_train_resampled_np[train_idx])
    y_pred_proba = best_model.predict_proba(X_train_selected[test_idx])[:, 1]
    fpr, tpr, _ = roc_curve(y_train_resampled_np[test_idx], y_pred_proba)
    tprs.append(np.interp(mean_fpr, fpr, tpr))
    tprs[-1][0] = 0.0
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
    plt.plot(fpr, tpr, lw=1, alpha=0.3, label='ROC fold %d (AUC = %0.4f)' % (i, roc_auc))

plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', alpha=.8)
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(aucs)
plt.plot(mean_fpr, mean_tpr, color='b',
         label=r'Mean ROC (AUC = %0.4f $\pm$ %0.4f)' % (mean_auc, std_auc),
         lw=2, alpha=.8)

std_tpr = np.std(tprs, axis=0)
tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,
                 label=r'$\pm$ 1 std. dev.')

plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('Internal Validation ROC Curve', fontweight='bold', fontsize=16)
plt.legend(loc="lower right", frameon=True)
plt.show()

print("Shape of X_train_selected:", X_train_selected.shape)
print("Shape of y_train_resampled:", y_train_resampled_np.shape)

