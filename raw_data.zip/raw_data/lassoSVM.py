# -*- coding: utf-8 -*-
"""
Created on Sat Jun  1 17:06:19 2024

@author: user
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, StratifiedKFold
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import Lasso
from scipy import stats
import shap
from sklearn.svm import SVC

random_state = 42

# 加载数据
data = pd.read_csv("C:/Users/user/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)
y = data['PCAA']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 过采样处理不平衡
smote = SMOTE(sampling_strategy=0.5)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42, stratify=y_resampled)

# 调整Lasso回归的alpha值进行特征选择
alpha_value = 0.02  # 调整alpha值，减小以保留更多特征
lasso_model = Lasso(alpha=alpha_value)
lasso_model.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_model.coef_

# 可视化Lasso回归系数
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title('Lasso Regression Coefficients')
plt.show()

# 绘制Lasso回归的特征选择过程折线图
alphas = np.logspace(-4, 0, 50)
coefs = []

for alpha in alphas:
    lasso = Lasso(alpha=alpha, max_iter=10000)
    lasso.fit(X_train, y_train)
    coefs.append(lasso.coef_)

plt.figure(figsize=(12, 8))
ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.xlabel('alpha')
plt.ylabel('Coefficients')
plt.title('Lasso Path')
plt.axis('tight')
plt.show()

# 使用Lasso回归系数筛选特征
selected_features = coefs_df['Feature'].values
X_train_selected = X_train[:, coefs_df.index]
X_test_selected = X_test[:, coefs_df.index]

# 训练SVM线性核模型
svc = SVC(kernel='linear', probability=True)

# 网格搜索调参
param_grid = {
    'C': [0.1, 1, 10, 100]
}
grid_search = GridSearchCV(estimator=svc, param_grid=param_grid, cv=StratifiedKFold(5), scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)

# 最佳模型
best_svc = grid_search.best_estimator_
print(grid_search.best_estimator_)

# 预测和评估
y_pred_train = best_svc.predict(X_train_selected)
y_pred_test = best_svc.predict(X_test_selected)

# 计算混淆矩阵和ROC AUC
conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)

print(conf_matrix_train)
print(conf_matrix_test)

# ROC曲线
y_pred_proba_test = best_svc.decision_function(X_test_selected)
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)

# 绘制ROC曲线
plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.legend(loc='lower right')
plt.title('SVM', fontweight='bold', fontsize=14)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN)
    specificity = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    PLR = sensitivity / (1 - specificity)
    NLR = (1 - sensitivity) / specificity
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证得分
scores = cross_val_score(svc, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出F1值等评估
print(classification_report(y_test, y_pred_test))

# Convert arrays back to DataFrame for interpretability with correct column names after feature selection
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_svc, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# SHAP总结图
shap.summary_plot(shap_values, X_test_selected_df)
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar')

# SHAP依赖图
for name in X_train_selected_df.columns:
    shap.dependence_plot(name, shap_values.values, X_test_selected_df)