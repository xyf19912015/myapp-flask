# -*- coding: utf-8 -*-
"""
Created on Thu May 30 20:39:11 2024

@author: user
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, auc, confusion_matrix, classification_report

# 读取数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/preROC.csv", encoding='UTF-8')

# 打印所有列标签
print(data.columns)

# 提取预测结果和真实结果
y_true = data['CAA']
y_pred = data['KDPCAAPro']

# 计算 ROC 曲线和 AUC
# 计算 ROC 曲线和 AUC
fpr, tpr, thresholds = roc_curve(y_true, y_pred)
roc_auc = auc(fpr, tpr)

# 计算敏感度和特异度
tn, fp, fn, tp = confusion_matrix(y_true, y_pred.round()).ravel()
sensitivity = tp / (tp + fn)
specificity = tn / (tn + fp)

# 绘制 ROC 曲线
# 绘制 ROC 曲线
plt.figure(figsize=(10, 6))
plt.plot(fpr, tpr, color='b', lw=2, alpha=0.8, label='ROC (AUC = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', alpha=0.8)
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('External Validation ROC Curve', fontweight='bold', fontsize=16)
plt.legend(loc="lower right", fontsize=12)
plt.grid(False)  # 去掉背景中的虚线
plt.show()

# 输出 ROC AUC, 敏感度, 特异度
print("ROC AUC: ", roc_auc)
print("Sensitivity: ", sensitivity)
print("Specificity: ", specificity)

# 输出 ROC AUC, 敏感度, 特异度
print("ROC AUC: ", roc_auc)
print("Sensitivity: ", sensitivity)
print("Specificity: ", specificity)

# 混淆矩阵
conf_matrix = confusion_matrix(y_true, y_pred.round())
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.title('Confusion Matrix', fontweight='bold', fontsize=16)
plt.xlabel('Predicted', fontsize=14)
plt.ylabel('Actual', fontsize=14)
plt.show()

# 输出性能指标
print(classification_report(y_true, y_pred.round()))

# 计算性能指标
accuracy = (tp + tn) / (tp + tn + fp + fn)
precision = tp / (tp + fp)
recall = tp / (tp + fn)
f1_score = 2 * (precision * recall) / (precision + recall)

# 输出性能指标
print("Accuracy: ", accuracy)
print("Precision: ", precision)
print("Recall: ", recall)
print("F1 Score: ", f1_score)