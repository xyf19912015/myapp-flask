# -*- coding: utf-8 -*-
"""
Created on Fri May 10 15:34:00 2024

@author: user
"""

import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 创建示例数据集
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS1.csv",encoding='gbk')
# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']
df = pd.DataFrame(X)

# 计算特征之间的相关性矩阵
corr_matrix = df.corr()

# 使用seaborn绘制热图
plt.figure(figsize=(8, 6))
heatmap = sns.heatmap(corr_matrix, annot=True, cmap="YlGnBu")
plt.title('Feature Correlation Heatmap')
plt.show()

import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取数据库文件
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)
y = data['PCAA']
df = pd.DataFrame(X)

# 计算特征之间的相关性矩阵
corr_matrix = df.corr()

# 使用seaborn绘制热图
plt.figure(figsize=(12, 10))  # 调整图表大小
heatmap = sns.heatmap(corr_matrix, annot=True, cmap="YlGnBu", fmt=".2f", annot_kws={"size": 10})
plt.title('Feature Correlation Heatmap', fontsize=16)
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.yticks(rotation=0, fontsize=10)
plt.show()