# -*- coding: utf-8 -*-
"""
Created on Tue May 14 17:56:00 2024

@author: user
"""

# 导入所需的库
import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import seaborn as sns
import matplotlib.pyplot as plt

# 读取数据库文件
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv",encoding='gbk')

# 使用pandas计算特征之间的相关性
correlation_matrix = data.corr()

# 使用VIF（方差膨胀因子）来分析特征共线性
features = data.drop(columns=['PCAA'])  # 假设目标变量所在的列名为'target_column'
X = sm.add_constant(features)
vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(X.values, i) for i in range(1, X.shape[1])]
vif["features"] = features.columns

# 打印VIF结果
print(vif)

# 可视化VIF值
plt.figure(figsize=(10, 6))
sns.barplot(x='VIF Factor', y='features', data=vif, palette='viridis')

plt.title('Variance Inflation Factors (VIF)')
plt.xlabel('VIF Value')
plt.ylabel('Features')
plt.show()
