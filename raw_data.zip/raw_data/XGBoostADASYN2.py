# 导入必要的库
from xgboost import XGBClassifier  # 导入XGBoost类
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import ADASYN  # 使用 ADASYN 替代 SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.metrics import (confusion_matrix, roc_curve, roc_auc_score,
                             classification_report, f1_score, precision_score,
                             recall_score, accuracy_score)
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso
import shap
from scipy.stats import sem, t
# 设置绘图风格
plt.style.use('seaborn-v0_8-darkgrid')  # 修正seaborn样式警告
random_state = 42
sns.set_palette("husl")

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)
y = data['PCAA']

# 训练集和测试集分割
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=random_state, stratify=y
)

# 特征标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 过采样处理（仅作用于训练集）
adasyn = ADASYN(sampling_strategy=0.5, random_state=random_state)
X_resampled, y_resampled = adasyn.fit_resample(X_train_scaled, y_train)

# 使用 LassoCV 进行特征选择
lasso_cv = LassoCV(alphas=np.logspace(-4, 1, 50), cv=10, max_iter=10000, random_state=random_state)
lasso_cv.fit(X_resampled, y_resampled)

# 获取最佳 alpha 值并获取Lasso系数
best_alpha = lasso_cv.alpha_
print(f"Optimal alpha value: {best_alpha}")

lasso_model = Lasso(alpha=best_alpha)
lasso_model.fit(X_resampled, y_resampled)
lasso_coefs = lasso_model.coef_

# 获取选择的特征
feature_names = X.columns.tolist()
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0].sort_values('Coefficient', ascending=False)

# 可视化 Lasso 回归系数
plt.figure(figsize=(10, 8), dpi=120)
barplot = sns.barplot(
    x='Coefficient', 
    y='Feature', 
    data=coefs_df,
    palette=['#FF6B6B' if x > 0 else '#4ECDC4' for x in coefs_df['Coefficient']],
    edgecolor='w',
    linewidth=1.5,
    saturation=0.85
)
plt.title(f'Lasso Regression Coefficients (α = {best_alpha:.4f})\n', fontsize=14, fontweight='bold')
plt.xlabel('\nCoefficient Magnitude', fontsize=12)
plt.ylabel('Feature Name', fontsize=12)
plt.axvline(0, color='#636e72', linestyle='--', linewidth=1)
plt.grid(axis='x', linestyle=':', alpha=0.7)
plt.tight_layout()
plt.show()

# 筛选特征
selected_features = coefs_df['Feature'].values
selected_indices = [feature_names.index(feat) for feat in selected_features]  # 直接使用列表查找

X_train_selected = X_resampled[:, selected_indices]
X_test_selected = X_test_scaled[:, selected_indices]

print(f"Selected features at alpha={best_alpha}: {len(selected_features)}")

# 训练 XGBoost 模型
xgb_classifier = XGBClassifier(random_state=random_state,eval_metric='logloss')

# 使用网格搜索进行超参数调优（若需要）
param_grid = {
    'n_estimators': [400],
    'learning_rate': [0.01],
    'max_depth': [6],
    'min_child_weight': [1],
    'gamma': [0.1],
    'subsample': [1.0],
    'colsample_bytree': [0.5],
    'reg_alpha': [0.01],
    'reg_lambda': [0.1]
}

grid_search = GridSearchCV(
    estimator=xgb_classifier, 
    param_grid=param_grid, 
    cv=5, 
    scoring='accuracy', 
    n_jobs=-1
)
grid_search.fit(X_train_selected, y_resampled)

best_xgb = grid_search.best_estimator_

# 预测和评估
y_pred_train = best_xgb.predict(X_train_selected)
y_pred_test = best_xgb.predict(X_test_selected)

# 混淆矩阵
conf_matrix_test = confusion_matrix(y_test, y_pred_test)
print("\nTesting Confusion Matrix:")
print(conf_matrix_test)

# ROC曲线
plt.figure(figsize=(10, 8))
y_pred_proba_test = best_xgb.predict_proba(X_test_selected)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)

plt.plot(fpr, tpr, color='b', lw=2, label=f'ROC Curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('XGBoost ROC Curve', fontweight='bold', fontsize=14)
plt.legend(loc="lower right")
plt.grid(True, alpha=0.5)
plt.tight_layout()
plt.show()



# 在预测和评估后进行 ROC 曲线的计算
y_pred_proba_test = best_xgb.predict_proba(X_test_selected)[:, 1]
fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba_test)

# 计算约登指数
j_scores = tpr - fpr
optimal_idx = np.argmax(j_scores)
optimal_threshold = thresholds[optimal_idx]

# 输出约登指数和最优阈值
print(f"约登指数 (Youden's J): {j_scores[optimal_idx]:.4f}")
print(f"最优阈值: {optimal_threshold:.4f}")

# 可视化约登指数和阈值
plt.figure(figsize=(10, 6))
plt.plot(thresholds, j_scores, color='blue', label="Youden's J Score")
plt.axvline(optimal_threshold, color='red', linestyle='--', label='Optimal Threshold')
plt.xlabel('Threshold')
plt.ylabel("Youden's J Score")
plt.title("Youden's J Score vs. Threshold")
plt.grid()
plt.legend()
plt.show()
# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    metrics = {
        'Accuracy': (TP + TN) / (TP + FP + FN + TN),
        'Sensitivity': TP / (TP + FN) if (TP + FN) != 0 else 0,
        'Specificity': TN / (TN + FP) if (TN + FP) != 0 else 0,
        'PPV': TP / (TP + FP) if (TP + FP) != 0 else 0,
        'NPV': TN / (TN + FN) if (TN + FN) != 0 else 0,
        'F1 Score': f1_score(y_test, y_pred_test),
        'Precision': precision_score(y_test, y_pred_test),
        'Recall': recall_score(y_test, y_pred_test)
    }
    return metrics

# 计算模型评估指标
test_metrics = calculate_performance(conf_matrix_test)
print("\nPerformance Metrics:")
for k, v in test_metrics.items():
    print(f"{k + ':':<20} {v:.4f}")

# 打印分类报告
print("\nClassification Report:")
print(classification_report(y_test, y_pred_test))

from sklearn.model_selection import StratifiedKFold
from imblearn.over_sampling import ADASYN
from sklearn.metrics import roc_curve, roc_auc_score, auc
import matplotlib.pyplot as plt
import numpy as np

# 设置参数
random_state = 42
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
mean_fpr = np.linspace(0, 1, 100)
tprs, aucs = [], []
accs, precisions, recalls, f1s = [], [], [], []

plt.figure(figsize=(10, 10))

for i, (train_idx, test_idx) in enumerate(cv.split(X_train_scaled, y_train)):
    X_fold_train, y_fold_train = X_train_scaled[train_idx], y_train.iloc[train_idx]
    X_fold_valid, y_fold_valid = X_train_scaled[test_idx], y_train.iloc[test_idx]
    
    # 过采样
    X_res, y_res = ADASYN(sampling_strategy=0.5, random_state=random_state).fit_resample(X_fold_train, y_fold_train)
    
    # 特征选择
    X_res_selected = X_res[:, selected_indices]
    X_val_selected = X_fold_valid[:, selected_indices]

    # 训练
    best_xgb.fit(X_res_selected, y_res)
    y_pred = best_xgb.predict(X_val_selected)
    y_proba = best_xgb.predict_proba(X_val_selected)[:, 1]

    # 评估指标
    accs.append(accuracy_score(y_fold_valid, y_pred))
    precisions.append(precision_score(y_fold_valid, y_pred))
    recalls.append(recall_score(y_fold_valid, y_pred))
    f1s.append(f1_score(y_fold_valid, y_pred))

    # ROC
    fpr, tpr, _ = roc_curve(y_fold_valid, y_proba)
    tprs.append(np.interp(mean_fpr, fpr, tpr))
    tprs[-1][0] = 0.0
    auc_score = roc_auc_score(y_fold_valid, y_proba)
    aucs.append(auc_score)

    plt.plot(fpr, tpr, lw=1, alpha=0.3, label=f"Fold {i+1} AUC = {auc_score:.4f}")

# 平均 ROC 曲线
mean_tpr = np.mean(tprs, axis=0)
mean_auc = np.mean(aucs)
std_auc = np.std(aucs)
mean_tpr[-1] = 1.0

plt.plot(mean_fpr, mean_tpr, color='b', lw=2, alpha=.8, label=f"Mean ROC (AUC = {mean_auc:.4f} ± {std_auc:.4f})")
plt.fill_between(mean_fpr, np.maximum(mean_tpr - np.std(tprs, axis=0), 0),
                 np.minimum(mean_tpr + np.std(tprs, axis=0), 1), color='grey', alpha=0.2, label="±1 std dev")

plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', alpha=0.8)
plt.xlabel('False Positive Rate',fontsize=14)
plt.ylabel('True Positive Rate',fontsize=14)
plt.title('Cross-Validation ROC Curve',fontweight='bold', fontsize=16)
plt.legend(loc="lower right")
plt.tight_layout()
plt.show()

# ========== 输出平均指标及95%置信区间 ==========
def mean_ci(values, confidence=0.95):
    n = len(values)
    mean_val = np.mean(values)
    std_err = sem(values)
    h = std_err * t.ppf((1 + confidence) / 2., n-1)
    return mean_val, h

metrics = {
    'Accuracy': accs,
    'Precision': precisions,
    'Recall': recalls,
    'F1-score': f1s,
    'AUC': aucs
}

print("\nCross-Validation Metrics with 95% Confidence Interval:")
for name, values in metrics.items():
    mean_val, ci = mean_ci(values)
    print(f"{name:<10}: {mean_val:.4f} ± {ci:.4f}")




    # SHAP 分析
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)
explainer = shap.Explainer(best_xgb, X_train_selected)
shap_values = explainer(X_test_selected_df, check_additivity=False)

    # SHAP 概要图
plt.figure(figsize=(12, 6))
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False)
plt.title("SHAP Feature Impact", fontweight='bold')
plt.tight_layout()
plt.show()



# --------------------------- SHAP 可视化增强部分 ---------------------------



# 转换数组回数据框以便于后续解释
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_xgb, X_train_selected_df)

# 尝试在计算SHAP值时设置check_additivity=False
shap_values = explainer(X_test_selected_df, check_additivity=False)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# 使用 gridspec 创建共享 y 轴的子图
fig = plt.figure(figsize=(14, 6))  # 调整图的大小以保持比例1:1
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])  # 设置比例为1:1

# 创建第一个子图 (点图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False, cmap="plasma")
ax1.set_title("SHAP Summary Plot (Dot)")

# 创建第二个子图 (柱状图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values, X_test_selected_df, plot_type="bar", show=False, cmap="plasma")
ax2.set_title("SHAP Summary Plot (Bar)")

# 获取柱状图的条
bars = ax2.patches

# 设置每个条的颜色为秋叶金
goldenrod = '#DAA520'  # 秋叶金的十六进制代码
for bar in bars:
    bar.set_facecolor(goldenrod)

# 隐藏第二个子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整子图之间的间距
plt.subplots_adjust(wspace=0.3)  # 根据需要调整 wspace 来增加或减少间距

# 调整布局
plt.tight_layout()
plt.show()




# --------------------------- 样本级解释可视化 ---------------------------
for name in X_train_selected_df.columns:
    shap.dependence_plot(name, shap_values.values, X_test_selected_df, show=False)



num_samples_to_show = 1
sample_indices = np.random.choice(X_test_selected_df.shape[0], num_samples_to_show, replace=False)

for idx in sample_indices:
    # 瀑布图
    plt.figure(figsize=(12, 6))
    
    # 获取 SHAP 解释对象
    shap_explanation = shap.Explanation(
        values=shap_values[idx],  # 获取 SHAP 值
        base_values=explainer.expected_value,
        data=X_test_selected_df.iloc[idx],
        feature_names=selected_features
    )
    
    # 创建并显示瀑布图
    shap.waterfall_plot(shap_explanation, max_display=10, show=False)
    
    plt.title(f"Prediction Decomposition - Sample #{idx}\n(Actual Class: {y_test.iloc[idx]})", 
             fontsize=12, pad=20)
    plt.gcf().set_facecolor('white')
    plt.tight_layout()
    plt.show()
    
    # # 强制关闭当前绘图
    # plt.close()  # 关闭当前绘图
    
    # 力图（带原始值格式化）
    formatted_features = X_test_selected_df.iloc[idx].copy().apply(
        lambda x: f"{x:.4f}" if isinstance(x, (int, float)) else str(x)
    )
    
    # 创建 SHAP 解释对象（力图所用）
    shap_explanation_force = shap.Explanation(
        values=shap_values[idx],  # 当前样本的 SHAP 值
        base_values=explainer.expected_value,
        data=X_test_selected_df.iloc[idx],
        feature_names=selected_features
    )
    
    # 修正：直接从 `explainer.expected_value` 获取期望值
    expected_value = explainer.expected_value
    
    # 创建并显示力图
    plt.figure(figsize=(12, 4))
    shap.force_plot(
        expected_value,  # 使用期望值
        shap_explanation_force.values,  # 当前样本的 SHAP 值
        formatted_features,
        matplotlib=True,
        text_rotation=15,
        contribution_threshold=0.05,
        show=False
    )
    plt.title(f"Feature Contribution Map - Sample #{idx}", fontsize=12, pad=20)
    plt.gcf().set_facecolor('white')
    plt.grid(False)
    plt.tight_layout()
    plt.show()
    
    # 强制关闭当前绘图
#    plt.close()  # 关闭当前绘图
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    