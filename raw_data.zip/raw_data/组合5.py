
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 16:37:20 2024

@author: Administrator
"""

# 导入必要的库
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.linear_model import LassoCV, Lasso, LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, StratifiedKFold
from sklearn.metrics import (confusion_matrix, roc_curve, roc_auc_score, classification_report,
                             auc, precision_recall_curve, f1_score, precision_score, recall_score)
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from scipy import stats
import shap  # 导入SHAP库
# from decisioncurvepy import decision_curve  # 混淆的决策曲线分析库
# 设置绘图风格
plt.style.use('seaborn-darkgrid')

# # 设置绘图风格
# sns.set(style='whitegrid')
# # 设置绘图风格
# plt.style.use('seaborn-whitegrid')
# 设置随机种子
random_state = 42

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDlast3.csv", encoding='gbk')

# 特征和标签
X = data.drop('PCAA', axis=1)
y = data['PCAA']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 过采样处理不平衡
smote = SMOTE(sampling_strategy=0.5, random_state=random_state)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(
    X_resampled, y_resampled, test_size=0.2, random_state=random_state, stratify=y_resampled
)

# 使用LassoCV进行特征选择
lasso_cv = LassoCV(alphas=np.logspace(-4, 1, 50), cv=5, max_iter=10000, random_state=random_state)
lasso_cv.fit(X_train, y_train)

# 最佳alpha值
best_alpha = lasso_cv.alpha_
print(f"Optimal alpha value: {best_alpha}")

# 使用最佳alpha值拟合Lasso模型
lasso_model = Lasso(alpha=best_alpha)
lasso_model.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_model.coef_

# 可视化Lasso回归系数（柱状图）
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 8))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title(f'Lasso Regression Coefficients (alpha={best_alpha})')
plt.xlabel('Coefficient')
plt.ylabel('Feature')
plt.tight_layout()
#plt.grid(axis='y')
plt.show()

# 手动计算Lasso回归系数路径
alphas = np.logspace(-4, 1, 50)
coefs = []  # 用于存储每个alpha值对应的系数
for alpha in alphas:
    lasso_temp = Lasso(alpha=alpha)
    lasso_temp.fit(X_train, y_train)
    coefs.append(lasso_temp.coef_)

# 将系数列表转换为NumPy数组，以便后续绘图
coefs = np.array(coefs)

# 绘制Lasso回归系数路径折线图
plt.figure(figsize=(10, 8))
for i in range(coefs.shape[1]):  # 对每个特征绘图
    plt.plot(alphas, coefs[:, i], label=feature_names[i])
plt.axvline(best_alpha, linestyle='--', color='k', label='Optimal alpha')
plt.xscale('log')
plt.xlabel('Alpha')
plt.ylabel('Coefficient')
plt.title('Lasso Paths')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize='small',frameon=True)
plt.tight_layout()
plt.grid(axis='y')
plt.show()

# 使用Lasso回归系数筛选特征
selected_features = coefs_df['Feature'].values
selected_indices = [list(feature_names).index(feat) for feat in selected_features]
X_train_selected = X_train[:, selected_indices]
X_test_selected = X_test[:, selected_indices]

print(f"Number of selected features at alpha={best_alpha}: {len(selected_features)}")

# 初始化模型字典，添加更多模型
models = {
    'XGBoost': XGBClassifier(random_state=random_state, use_label_encoder=False, eval_metric='logloss'),
    # 'LightGBM': LGBMClassifier(random_state=random_state),
    'CatBoost': CatBoostClassifier(random_state=random_state, verbose=0),
    'LR': LogisticRegression(random_state=random_state, max_iter=1000),
    'RF': RandomForestClassifier(random_state=random_state),
    'DT': DecisionTreeClassifier(random_state=random_state),
    'AdaBoost': AdaBoostClassifier(random_state=random_state),
    'GB': GradientBoostingClassifier(random_state=random_state),
    'SVM': SVC(kernel='linear', probability=True, random_state=random_state),
    'GNB': GaussianNB(),
    'MLP': MLPClassifier(random_state=random_state, max_iter=1000)
}

# 初始化参数网格，为每个模型添加适当的参数
param_grids = {
    'XGBoost': {
        'n_estimators': [100],  # 选择适中数量的树
        'learning_rate': [0.1],  # 常用的学习速率
        'max_depth': [5],  # 限制树的深度防止过拟合
        'min_child_weight': [1],  # 调整子节点权重以防止过拟合
        'gamma': [0.1],  # 控制是否增加额外的分裂
        'subsample': [0.8],  # 控制每棵树使用的样本比例
        'colsample_bytree': [0.6],  # 控制每棵树使用的特征比例
        'reg_lambda': [1],  # 使用L2正则化以防止过拟合
        'reg_alpha': [0.1]  # 使用L1正则化
    },
    # 'LightGBM': {
    #     'n_estimators': [100, 200],  # 与XGBoost相似
    #     'learning_rate': [0.01, 0.05, 0.1],
    #     'num_leaves': [31, 50],  # 控制树的数量以防止过拟合
    #     'max_depth': [10, 15],  # 最大深度
    #     'min_child_samples': [20],  # 最小样本数
    #     'subsample': [0.6, 0.8],
    #     'colsample_bytree': [0.6, 0.8],
    #     'reg_lambda': [1],  # L2正则化
    #     'reg_alpha': [0, 0.1]  # L1正则化
    # },
    'CatBoost': {
        'iterations': [200],  # 也和上面保持一致
        'learning_rate': [0.1],
        'depth': [5],  # 深度选择有限
        'l2_leaf_reg': [1],  # L2正则化
        'border_count': [32]  # 边界数选择
    },
    'LR': {
        'C': [0.1],  # 正则化参数选择
        'penalty': ['l2'],  # L2正则化
        'solver': ['lbfgs']  # 常用的优化器
    },
    'RF': {
        'n_estimators': [200],  # 树的数量
        'max_depth': [None],  # 要考虑进深度限制
        'min_samples_split': [2],  # 默认分割样本数
        'min_samples_leaf': [1],  # 对叶子节点的限制
        'max_features': ['sqrt']  # 选择平方根特征
    },
    'DT': {
        'max_depth': [10],  # 限制树深度
        'min_samples_split': [2],  # 默认的样本分割数量
        'min_samples_leaf': [1],  # 默认的叶子样本数量
        'criterion': ['gini']  # 默认的质量测量
    },
    'AdaBoost': {
        'n_estimators': [100],  # 使用的基模型数量
        'learning_rate': [0.1]  # 学习率
    },
    'GB': {
        'n_estimators': [200],
        'learning_rate': [0.1],
        'max_depth': [5],
        'min_samples_split': [2]
    },
    'SVM': {
        'C': [0.1],  # 正则化参数
        'kernel': ['linear']  # 内核选择
    },
    'GNB': {
        'var_smoothing': [1e-09]  # 平滑参数
    },
    'MLP': {
        'hidden_layer_sizes': [(50,), (100,)],  # 隐藏层大小
        'activation': ['relu'],  # 激活函数
        'solver': ['adam'],  # 优化器
        'alpha': [0.001]  # L2正则化
    }
}
# 存储模型的ROC曲线和PR曲线数据
roc_data = {}
pr_data = {}

# 定义交叉验证策略
cv_strategy = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)

# 存储模型性能以便后续选择最优模型
model_performance = {}

# 存储最佳参数
best_params = {}

# 初始化prob_predictions字典，用于存储每个模型的预测概率
prob_predictions = {}

# 存储评估指标
evaluation_metrics = {
    'Model': [],
    'Accuracy': [],
    'Sensitivity (Recall)': [],
    'Specificity': [],
    'Positive Predictive Value (Precision)': [],
    'Negative Predictive Value': [],
    'Positive Likelihood Ratio': [],
    'Negative Likelihood Ratio': [],
    'F1 Score': [],
    'Precision': [],
    'Recall': [],
    'ROC AUC (Test)': [],
    'F1 Score': [],
    'Precision': [],
    'Recall': []
}

# 遍历每个模型进行训练、预测和评估
for model_name, model in models.items():
    print(f"\nTraining and evaluating {model_name}...")
    
    # 获取对应的参数网格
    param_grid = param_grids.get(model_name, {})
    
    # 网格搜索
    grid_search = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        cv=cv_strategy,
        scoring='roc_auc',
        n_jobs=-1,
        verbose=0
    )
    grid_search.fit(X_train_selected, y_train)
    
    # 最佳模型
    best_model = grid_search.best_estimator_
    print(f"Best parameters for {model_name}: {grid_search.best_params_}")
    
    
    # 交叉验证得分
    cv_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='accuracy', n_jobs=-1)
    avg_accuracy = cv_scores.mean()  # 计算平均准确率
    std_accuracy = cv_scores.std()    # 计算标准差
   
    # 计算95%置信区间
    confidence_interval = stats.t.interval(0.95, len(cv_scores)-1, loc=avg_accuracy, scale=stats.sem(cv_scores))
   
    # 打印准确率和置信区间
    print(f"Average Accuracy: {avg_accuracy:.4f} (95% confidence interval: {confidence_interval})")
    # 存储最佳参数
    best_params[model_name] = grid_search.best_params_
    
    # 预测
    y_pred_train = best_model.predict(X_train_selected)
    y_pred_test = best_model.predict(X_test_selected)
    
    # 混淆矩阵
    conf_matrix_test = confusion_matrix(y_test, y_pred_test)
    print(f"Confusion Matrix for {model_name} on Test Set:\n{conf_matrix_test}")
    
    # 分类报告
    print(f"Classification Report for {model_name}:\n{classification_report(y_test, y_pred_test)}")
    
    # ROC曲线数据
    if hasattr(best_model, "predict_proba"):
        y_pred_proba_test = best_model.predict_proba(X_test_selected)[:, 1]
        y_pred_proba_train = best_model.predict_proba(X_train_selected)[:, 1]
    elif hasattr(best_model, "decision_function"):
        y_pred_proba_test = best_model.decision_function(X_test_selected)
        y_pred_proba_train = best_model.decision_function(X_train_selected)
    else:
        y_pred_proba_test = y_pred_test  # 无法获得概率时使用预测结果
        y_pred_proba_train = y_pred_train
    
    # 存储预测概率
    prob_predictions[model_name] = y_pred_proba_test
    
    fpr_test, tpr_test, _ = roc_curve(y_test, y_pred_proba_test)
    roc_auc_test = roc_auc_score(y_test, y_pred_proba_test)
    
    fpr_train, tpr_train, _ = roc_curve(y_train, y_pred_proba_train)
    roc_auc_train = roc_auc_score(y_train, y_pred_proba_train)
    
    roc_data[model_name] = {
        'fpr_train': fpr_train,
        'tpr_train': tpr_train,
        'roc_auc_train': roc_auc_train,
        'fpr_test': fpr_test,
        'tpr_test': tpr_test,
        'roc_auc_test': roc_auc_test
    }
    
    # PR曲线数据
    precision_test, recall_test, _ = precision_recall_curve(y_test, y_pred_proba_test)
    pr_auc_test = auc(recall_test, precision_test)
    
    precision_train, recall_train, _ = precision_recall_curve(y_train, y_pred_proba_train)
    pr_auc_train = auc(recall_train, precision_train)
    
    pr_data[model_name] = {
        'precision_train': precision_train,
        'recall_train': recall_train,
        'pr_auc_train': pr_auc_train,
        'precision_test': precision_test,
        'recall_test': recall_test,
        'pr_auc_test': pr_auc_test
    }
 
    # 计算性能指标
    acc = (conf_matrix_test[0,0] + conf_matrix_test[1,1]) / np.sum(conf_matrix_test)
    sens = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[1,0]) if (conf_matrix_test[1,1] + conf_matrix_test[1,0]) != 0 else 0
    spec = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[0,1]) if (conf_matrix_test[0,0] + conf_matrix_test[0,1]) != 0 else 0
    ppv = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[0,1]) if (conf_matrix_test[1,1] + conf_matrix_test[0,1]) != 0 else 0
    npv = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[1,0]) if (conf_matrix_test[0,0] + conf_matrix_test[1,0]) != 0 else 0
    plr = sens / (1 - spec) if (1 - spec) != 0 else 0
    nlr = (1 - sens) / spec if spec != 0 else 0
    f1 = f1_score(y_test, y_pred_test)
    precision = precision_score(y_test, y_pred_test)
    recall = recall_score(y_test, y_pred_test)
    
    print(f"{model_name} Performance Metrics:")
    print(f"Accuracy: {acc:.4f}")
    print(f"Sensitivity (Recall): {sens:.4f}")
    print(f"Specificity: {spec:.4f}")
    print(f"Positive Predictive Value (Precision): {ppv:.4f}")
    print(f"Negative Predictive Value: {npv:.4f}")
    print(f"Positive Likelihood Ratio: {plr:.4f}")
    print(f"Negative Likelihood Ratio: {nlr:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    
    # 交叉验证得分
    cv_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='roc_auc', n_jobs=-1)
    print(f"Cross-Validation ROC AUC for {model_name}: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    
    # 置信区间
    confidence_interval = stats.t.interval(0.95, len(cv_scores)-1, loc=np.mean(cv_scores), scale=stats.sem(cv_scores))
    print(f"95% Confidence Interval for {model_name}: {confidence_interval}")
    
    # 存储模型性能
    model_performance[model_name] = {
        'roc_auc_test': roc_auc_test,
        'f1_score': f1,
        'precision': precision,
        'recall': recall
    }
    
    # 存储评估指标到字典
    evaluation_metrics['Model'].append(model_name)
    evaluation_metrics['Accuracy'].append(acc)
    evaluation_metrics['Sensitivity (Recall)'].append(sens)
    evaluation_metrics['Specificity'].append(spec)
    evaluation_metrics['Positive Predictive Value (Precision)'].append(ppv)
    evaluation_metrics['Negative Predictive Value'].append(npv)
    evaluation_metrics['Positive Likelihood Ratio'].append(plr)
    evaluation_metrics['Negative Likelihood Ratio'].append(nlr)
    evaluation_metrics['F1 Score'].append(f1)
    evaluation_metrics['Precision'].append(precision)
    evaluation_metrics['Recall'].append(recall)
    evaluation_metrics['ROC AUC (Test)'].append(roc_auc_test)

# 创建最佳参数的数据框
best_params_df = pd.DataFrame.from_dict(best_params, orient='index').reset_index()
best_params_df = best_params_df.rename(columns={'index': 'Model'})
print("\nBest Parameters for Each Model:")
print(best_params_df)

# 保存最佳参数到CSV
best_params_df.to_csv("best_parameters.csv", index=False, encoding='utf-8-sig')
print("Best parameters have been saved to 'best_parameters.csv'.")

# 创建评估指标的数据框
evaluation_metrics_df = pd.DataFrame(evaluation_metrics)
print("\nEvaluation Metrics for Each Model:")
print(evaluation_metrics_df)

# 保存评估指标到CSV
evaluation_metrics_df.to_csv("evaluation_metrics.csv", index=False, encoding='utf-8-sig')
print("Evaluation metrics have been saved to 'evaluation_metrics.csv'.")

# 绘制所有模型的ROC曲线（测试集）
plt.figure(figsize=(10, 8))
for model_name, data_roc in roc_data.items():
    plt.plot(data_roc['fpr_test'], data_roc['tpr_test'],
             label=f'{model_name} (AUC = {data_roc["roc_auc_test"]:.4f})')
plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
plt.title('ROC Curves for Multiple Models (Test Set)', fontweight='bold', fontsize=16)
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.legend(loc='lower right', fontsize=12,frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()

# # 绘制所有模型的ROC曲线（训练集）
# plt.figure(figsize=(10, 8))
# for model_name, data_roc in roc_data.items():
#     plt.plot(data_roc['fpr_train'], data_roc['tpr_train'],
#              label=f'{model_name} Train (AUC = {data_roc["roc_auc_train"]:.2f})')
# plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
# plt.title('ROC Curves for Multiple Models (Train Set)', fontweight='bold', fontsize=16)
# plt.xlabel('False Positive Rate', fontsize=14)
# plt.ylabel('True Positive Rate', fontsize=14)
# plt.legend(loc='lower right', fontsize=12)
# plt.grid(True)
# plt.tight_layout()
# plt.show()

# 绘制所有模型的PR曲线（测试集）
plt.figure(figsize=(10, 8))
for model_name, data_pr in pr_data.items():
    plt.plot(data_pr['recall_test'], data_pr['precision_test'],
              label=f'{model_name} (PR AUC = {data_pr["pr_auc_test"]:.4f})')
plt.title('Precision-Recall Curves for Multiple Models (Test Set)', fontweight='bold', fontsize=16)
plt.xlabel('Recall', fontsize=14)
plt.ylabel('Precision', fontsize=14)
plt.legend(loc='lower left', fontsize=12,frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()
# # 打印各模型的 PR AUC
# print("各模型的 PR AUC 值：")
# for model_name, data_pr in pr_data.items():
#     print(f"{model_name}: PR AUC = {data_pr['pr_auc_test']:.4f}")

# # 绘制所有模型的PR曲线（训练集）
# plt.figure(figsize=(10, 8))
# for model_name, data_pr in pr_data.items():
#     plt.plot(data_pr['recall_train'], data_pr['precision_train'],
#              label=f'{model_name} Train (PR AUC = {data_pr["pr_auc_train"]:.2f})')
# plt.title('Precision-Recall Curves for Multiple Models (Train Set)', fontweight='bold', fontsize=16)
# plt.xlabel('Recall', fontsize=14)
# plt.ylabel('Precision', fontsize=14)
# plt.legend(loc='lower left', fontsize=12,frameon=True)
# plt.grid(True)
# plt.tight_layout()
# plt.show()

# 绘制特征重要性（以最佳模型为例）
best_model_name = max(model_performance, key=lambda x: model_performance[x]['roc_auc_test'])
best_model = models[best_model_name]
best_model.fit(X_train_selected, y_train)  # 确保模型已训练

plt.figure(figsize=(10, 8))
importances = best_model.feature_importances_ if hasattr(best_model, 'feature_importances_') else None
if importances is not None:
    indices = np.argsort(importances)[::-1]
    sorted_features = selected_features[indices]
    sorted_importances = importances[indices]
    sns.barplot(x=sorted_importances, y=sorted_features)
    plt.title(f'Feature Importances ({best_model_name})')
    plt.xlabel('Importance')
    plt.ylabel('Feature')
    plt.tight_layout()
    plt.show()
else:
    print(f"{best_model_name} does not have feature_importances_ attribute.")





import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV, learning_curve, cross_val_score
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, roc_auc_score, precision_recall_curve, auc, f1_score, precision_score, recall_score
from scipy import stats

# 假设 models 是一个字典，包含模型名称和对应的实例
# 例如：
# models = {
#     'Logistic Regression': LogisticRegression(),
#     'Random Forest': RandomForestClassifier(),
#     'XGBoost': XGBClassifier(),
#     # 其他模型
# }

# 初始化用于存储数据的结构
learning_curves = {}
f1_score_thresholds = {}
thresholds = np.linspace(0, 1, 100)

# 评估指标存储
evaluation_metrics = {
    'Model': [],
    'Accuracy': [],
    'Sensitivity (Recall)': [],
    'Specificity': [],
    'Positive Predictive Value (Precision)': [],
    'Negative Predictive Value': [],
    'Positive Likelihood Ratio': [],
    'Negative Likelihood Ratio': [],
    'F1 Score': [],
    'Precision': [],
    'Recall': [],
    'ROC AUC (Test)': []
}

model_performance = {}
prob_predictions = {}
roc_data = {}
pr_data = {}

# 遍历每个模型进行训练、预测和评估
for model_name, model in models.items():
    print(f"\nTraining and evaluating {model_name}...")
    
    # 获取对应的参数网格
    param_grid = param_grids.get(model_name, {})
    
    # 网格搜索
    grid_search = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        cv=cv_strategy,
        scoring='roc_auc',
        n_jobs=-1,
        verbose=0
    )
    grid_search.fit(X_train_selected, y_train)
    
    # 最佳模型
    best_model = grid_search.best_estimator_
    print(f"Best parameters for {model_name}: {grid_search.best_params_}")
    
    # 存储最佳参数
    best_params[model_name] = grid_search.best_params_
    
    # 预测
    y_pred_train = best_model.predict(X_train_selected)
    y_pred_test = best_model.predict(X_test_selected)
    
    # 混淆矩阵
    conf_matrix_test = confusion_matrix(y_test, y_pred_test)
    print(f"Confusion Matrix for {model_name} on Test Set:\n{conf_matrix_test}")
    
    # 分类报告
    print(f"Classification Report for {model_name}:\n{classification_report(y_test, y_pred_test)}")
    
    # ROC曲线数据
    if hasattr(best_model, "predict_proba"):
        y_pred_proba_test = best_model.predict_proba(X_test_selected)[:, 1]
        y_pred_proba_train = best_model.predict_proba(X_train_selected)[:, 1]
    elif hasattr(best_model, "decision_function"):
        y_pred_proba_test = best_model.decision_function(X_test_selected)
        y_pred_proba_train = best_model.decision_function(X_train_selected)
    else:
        y_pred_proba_test = y_pred_test  # 无法获得概率时使用预测结果
        y_pred_proba_train = y_pred_train
    
    # 存储预测概率
    prob_predictions[model_name] = y_pred_proba_test
    
    fpr_test, tpr_test, _ = roc_curve(y_test, y_pred_proba_test)
    roc_auc_test = roc_auc_score(y_test, y_pred_proba_test)
    
    fpr_train, tpr_train, _ = roc_curve(y_train, y_pred_proba_train)
    roc_auc_train = roc_auc_score(y_train, y_pred_proba_train)
    
    roc_data[model_name] = {
        'fpr_train': fpr_train,
        'tpr_train': tpr_train,
        'roc_auc_train': roc_auc_train,
        'fpr_test': fpr_test,
        'tpr_test': tpr_test,
        'roc_auc_test': roc_auc_test
    }
    
    # PR曲线数据
    precision_test, recall_test, _ = precision_recall_curve(y_test, y_pred_proba_test)
    pr_auc_test = auc(recall_test, precision_test)
    
    precision_train, recall_train, _ = precision_recall_curve(y_train, y_pred_proba_train)
    pr_auc_train = auc(recall_train, precision_train)
    
    pr_data[model_name] = {
        'precision_train': precision_train,
        'recall_train': recall_train,
        'pr_auc_train': pr_auc_train,
        'precision_test': precision_test,
        'recall_test': recall_test,
        'pr_auc_test': pr_auc_test
    }
    
    # 计算性能指标
    acc = (conf_matrix_test[0,0] + conf_matrix_test[1,1]) / np.sum(conf_matrix_test)
    sens = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[1,0]) if (conf_matrix_test[1,1] + conf_matrix_test[1,0]) != 0 else 0
    spec = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[0,1]) if (conf_matrix_test[0,0] + conf_matrix_test[0,1]) != 0 else 0
    ppv = conf_matrix_test[1,1] / (conf_matrix_test[1,1] + conf_matrix_test[0,1]) if (conf_matrix_test[1,1] + conf_matrix_test[0,1]) != 0 else 0
    npv = conf_matrix_test[0,0] / (conf_matrix_test[0,0] + conf_matrix_test[1,0]) if (conf_matrix_test[0,0] + conf_matrix_test[1,0]) != 0 else 0
    plr = sens / (1 - spec) if (1 - spec) != 0 else 0
    nlr = (1 - sens) / spec if spec != 0 else 0
    f1 = f1_score(y_test, y_pred_test)
    precision = precision_score(y_test, y_pred_test)
    recall = recall_score(y_test, y_pred_test)
    
    print(f"{model_name} Performance Metrics:")
    print(f"Accuracy: {acc:.4f}")
    print(f"Sensitivity (Recall): {sens:.4f}")
    print(f"Specificity: {spec:.4f}")
    print(f"Positive Predictive Value (Precision): {ppv:.4f}")
    print(f"Negative Predictive Value: {npv:.4f}")
    print(f"Positive Likelihood Ratio: {plr:.4f}")
    print(f"Negative Likelihood Ratio: {nlr:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    
    # 交叉验证得分
    cv_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='roc_auc', n_jobs=-1)
    print(f"Cross-Validation ROC AUC for {model_name}: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    
    # 置信区间
    confidence_interval = stats.t.interval(0.95, len(cv_scores)-1, loc=np.mean(cv_scores), scale=stats.sem(cv_scores))
    print(f"95% Confidence Interval for {model_name}: {confidence_interval}")
    
    # 存储模型性能
    model_performance[model_name] = {
        'roc_auc_test': roc_auc_test,
        'f1_score': f1,
        'precision': precision,
        'recall': recall
    }
    
    # 存储评估指标到字典
    evaluation_metrics['Model'].append(model_name)
    evaluation_metrics['Accuracy'].append(acc)
    evaluation_metrics['Sensitivity (Recall)'].append(sens)
    evaluation_metrics['Specificity'].append(spec)
    evaluation_metrics['Positive Predictive Value (Precision)'].append(ppv)
    evaluation_metrics['Negative Predictive Value'].append(npv)
    evaluation_metrics['Positive Likelihood Ratio'].append(plr)
    evaluation_metrics['Negative Likelihood Ratio'].append(nlr)
    evaluation_metrics['F1 Score'].append(f1)
    evaluation_metrics['Precision'].append(precision)
    evaluation_metrics['Recall'].append(recall)
    evaluation_metrics['ROC AUC (Test)'].append(roc_auc_test)
    
    ### 收集学习曲线数据 ###
    train_sizes_lc, train_scores_lc, test_scores_lc = learning_curve(
        best_model, X_train_selected, y_train, cv=cv_strategy, n_jobs=-1, train_sizes=np.linspace(0.1, 1.0, 10)
    )
    train_mean_lc = np.mean(train_scores_lc, axis=1)
    test_mean_lc = np.mean(test_scores_lc, axis=1)
    
    learning_curves[model_name] = {
        'train_sizes': train_sizes_lc,
        'train_mean': train_mean_lc,
        'test_mean': test_mean_lc
    }
    
    ### 收集 F1 分数与阈值的数据 ###
    f1_scores = []
    for threshold in thresholds:
        y_pred_threshold = (y_pred_proba_test >= threshold).astype(int)
        f1 = f1_score(y_test, y_pred_threshold)
        f1_scores.append(f1)
    
    f1_score_thresholds[model_name] = f1_scores

# 循环结束后绘制集合图

# ### 绘制学习曲线的集合图 ###
# plt.figure(figsize=(10, 8))
# for model_name, lc_data in learning_curves.items():
#     plt.plot(lc_data['train_sizes'], lc_data['train_mean'], label=f'{model_name} Train')
#     plt.plot(lc_data['train_sizes'], lc_data['test_mean'], linestyle='--', label=f'{model_name} CV')
# plt.title('Learning Curves for All Models', fontweight='bold', fontsize=16)
# plt.xlabel('Training Size', fontsize=14)
# plt.ylabel('Score', fontsize=14)
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()

# ### 绘制 F1 分数与阈值关系图的集合图 ###
# plt.figure(figsize=(10, 8))
# for model_name, f1_scores in f1_score_thresholds.items():
#     plt.plot(thresholds, f1_scores, label=model_name)
# plt.title('F1 Score vs Thresholds for All Models', fontweight='bold', fontsize=16)
# plt.xlabel('Threshold', fontsize=14)
# plt.ylabel('F1 Score', fontsize=14)
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()






# 定义一个函数来计算净收益
def calculate_net_benefit(y_true, y_probs, thresholds):
    net_benefits = []
    for threshold in thresholds:
        # 预测为正类的样本
        y_pred = (y_probs >= threshold).astype(int)

        # 计算真阳性和假阳性
        TP = np.sum((y_pred == 1) & (y_true == 1))
        FP = np.sum((y_pred == 1) & (y_true == 0))

        # 总样本数
        N = len(y_true)

        # 确保不出现除以零情况
        if N == 0:
            net_benefit = 0
        else:
            if (TP + FP) == 0:  # 如果无正类预测
                net_benefit = 0
            else:
                net_benefit = (TP / N) - (FP / N) * (threshold / (1 - threshold))
        
        net_benefits.append(net_benefit)

    return net_benefits

# 定义阈值范围（使用0.1到0.9的范围）
thresholds = np.linspace(0.1, 0.9, 100)

# 计算并存储净收益
net_benefit_data = {}
best_thresholds = {}

for model_name, probs in prob_predictions.items():
    net_benefit = calculate_net_benefit(y_test.values, probs, thresholds)
    net_benefit_data[model_name] = net_benefit

    # 找到最大净收益及其对应的阈值
    max_net_benefit = max(net_benefit)
    best_threshold = thresholds[np.argmax(net_benefit)]
    best_thresholds[model_name] = (best_threshold, max_net_benefit)

    # 打印每个模型的最佳阈值和净收益
    print(f"{model_name} 最佳阈值: {best_threshold:.2f}, 最大净收益: {max_net_benefit:.4f}")

# 计算基线净收益（假设所有人都为阳性）
baseline_benefit = np.mean(y_test)

# 绘制 DCA 曲线
plt.figure(figsize=(10, 8))
for model_name, net_benefit in net_benefit_data.items():
    plt.plot(thresholds, net_benefit, label=model_name)

# 绘制基线参考线
plt.plot(thresholds, [baseline_benefit] * len(thresholds), 'k--', label='Hypothetical All Positive')

plt.title('Decision Curve Analysis (DCA)', fontweight='bold', fontsize=16)
plt.xlabel('Threshold Probability', fontsize=14)
plt.ylabel('Net Benefit', fontsize=14)
plt.legend(loc='lower left', fontsize=12,frameon=True)
plt.grid(True)
plt.tight_layout()
plt.show()

# # 添加所需的库
# import numpy as np
# import pandas as pd
# from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score

# # 假设 y_test 和 y_pred_proba_test 已在模型评估后计算
# # 在每个模型的评估后，添加以下计算最优阈值和约登指数的代码

# # 收集最优模型的预测概率
# final_model_name = max(model_performance, key=lambda x: model_performance[x]['roc_auc_test'])
# final_model_probs = prob_predictions[final_model_name]

# # 计算 ROC 曲线数据
# fpr, tpr, thresholds = roc_curve(y_test, final_model_probs)

# # 计算最优阈值
# youden_index = tpr - fpr  # 计算约登指数
# optimal_idx = np.argmax(youden_index)  # 找到最大约登指数的索引
# optimal_threshold = thresholds[optimal_idx]  # 对应的阈值

# print(f"Optimal threshold for {final_model_name}: {optimal_threshold:.4f}")
# print(f"Youden's Index: {youden_index[optimal_idx]:.4f}")

# # 可选：使用最优阈值进行预测
# y_pred_optimal = (final_model_probs >= optimal_threshold).astype(int)

# # 计算混淆矩阵
# conf_matrix_optimal = confusion_matrix(y_test, y_pred_optimal)
# print(f"Confusion Matrix at Optimal Threshold for {final_model_name}:\n{conf_matrix_optimal}")

# # 计算其他性能指标
# sensitivity_optimal = conf_matrix_optimal[1, 1] / (conf_matrix_optimal[1, 1] + conf_matrix_optimal[1, 0])
# specificity_optimal = conf_matrix_optimal[0, 0] / (conf_matrix_optimal[0, 0] + conf_matrix_optimal[0, 1])
# accuracy_optimal = (conf_matrix_optimal[0, 0] + conf_matrix_optimal[1, 1]) / np.sum(conf_matrix_optimal)

# print(f"Accuracy: {accuracy_optimal:.4f}")
# print(f"Sensitivity (Recall): {sensitivity_optimal:.4f}")
# print(f"Specificity: {specificity_optimal:.4f}")



# 遍历每个模型进行训练、预测和评估
for model_name, model in models.items():
    print(f"\nTraining and evaluating {model_name}...")
    
    # 获取对应的参数网格
    param_grid = param_grids.get(model_name, {})
    
    # 网格搜索
    grid_search = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        cv=cv_strategy,
        scoring='roc_auc',
        n_jobs=-1,
        verbose=0
    )
    grid_search.fit(X_train_selected, y_train)
    
    # 最佳模型
    best_model = grid_search.best_estimator_
    print(f"Best parameters for {model_name}: {grid_search.best_params_}")

    # 交叉验证得分
    accuracy_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='accuracy', n_jobs=-1)
    recall_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='recall', n_jobs=-1)
    precision_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='precision', n_jobs=-1)
    f1_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='f1', n_jobs=-1)
    roc_auc_scores = cross_val_score(best_model, X_train_selected, y_train, cv=cv_strategy, scoring='roc_auc', n_jobs=-1)

    # 输出每折的精确率、召回率、F1 Score，ROC AUC
    print(f"Accuracy for each fold: {accuracy_scores}")
    print(f"Recall for each fold: {recall_scores}")
    print(f"Precision for each fold: {precision_scores}")
    print(f"F1 Score for each fold: {f1_scores}")
    print(f"ROC AUC for each fold: {roc_auc_scores}")

    # 计算平均值和标准差
    print(f"Average Accuracy: {accuracy_scores.mean():.4f} ± {accuracy_scores.std():.4f}")
    print(f"Average Recall: {recall_scores.mean():.4f} ± {recall_scores.std():.4f}")
    print(f"Average Precision: {precision_scores.mean():.4f} ± {precision_scores.std():.4f}")
    print(f"Average F1 Score: {f1_scores.mean():.4f} ± {f1_scores.std():.4f}")
    print(f"Average ROC AUC: {roc_auc_scores.mean():.4f} ± {roc_auc_scores.std():.4f}")

    # 计算95%的置信区间
    confidence_interval_accuracy = stats.t.interval(0.95, len(accuracy_scores)-1, loc=np.mean(accuracy_scores), scale=stats.sem(accuracy_scores))
    confidence_interval_recall = stats.t.interval(0.95, len(recall_scores)-1, loc=np.mean(recall_scores), scale=stats.sem(recall_scores))
    confidence_interval_precision = stats.t.interval(0.95, len(precision_scores)-1, loc=np.mean(precision_scores), scale=stats.sem(precision_scores))
    confidence_interval_f1 = stats.t.interval(0.95, len(f1_scores)-1, loc=np.mean(f1_scores), scale=stats.sem(f1_scores))
    confidence_interval_roc_auc = stats.t.interval(0.95, len(roc_auc_scores)-1, loc=np.mean(roc_auc_scores), scale=stats.sem(roc_auc_scores))

    # 打印置信区间
    print(f"95% Confidence Interval for Accuracy: {confidence_interval_accuracy}")
    print(f"95% Confidence Interval for Recall: {confidence_interval_recall}")
    print(f"95% Confidence Interval for Precision: {confidence_interval_precision}")
    print(f"95% Confidence Interval for F1 Score: {confidence_interval_f1}")
    print(f"95% Confidence Interval for ROC AUC: {confidence_interval_roc_auc}")

# 结束遍历


# # 确定最佳模型
# best_model_name = max(model_performance, key=lambda x: model_performance[x]['roc_auc_test'])
# best_model = GridSearchCV(models[best_model_name], param_grids[best_model_name], cv=cv_strategy, scoring='roc_auc', n_jobs=-1).fit(X_train_selected, y_train).best_estimator_

# # 绘制学习曲线
# train_sizes, train_scores, test_scores = learning_curve(
#     best_model, X_train_selected, y_train, cv=cv_strategy, n_jobs=-1, train_sizes=np.linspace(0.1, 1.0, 10)
# )
# train_mean = np.mean(train_scores, axis=1)
# test_mean = np.mean(test_scores, axis=1)

# plt.figure(figsize=(10, 8))
# plt.plot(train_sizes, train_mean, label='Training Score')
# plt.plot(train_sizes, test_mean, label='Cross-Validation Score')
# plt.title(f'Learning Curve for {best_model_name}', fontweight='bold', fontsize=16)
# plt.xlabel('Training Size', fontsize=14)
# plt.ylabel('Score', fontsize=14)
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()

# # 计算并绘制 F1 Score vs Threshold
# f1_scores = []
# for threshold in thresholds:
#     y_pred_threshold = (prob_predictions[best_model_name] >= threshold).astype(int)
#     f1 = f1_score(y_test, y_pred_threshold)
#     f1_scores.append(f1)

# plt.figure(figsize=(10, 8))
# plt.plot(thresholds, f1_scores, label='F1 Score')
# plt.title(f'F1 Score vs Thresholds for {best_model_name}', fontweight='bold', fontsize=16)
# plt.xlabel('Threshold', fontsize=14)
# plt.ylabel('F1 Score', fontsize=14)
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()

# # ### 计算并绘制SHAP值和依赖图

# # 确定最优模型（以ROC AUC最高为准）
# best_model_name = max(model_performance, key=lambda x: model_performance[x]['roc_auc_test'])
# best_model = GridSearchCV(models[best_model_name], param_grids[best_model_name], cv=cv_strategy, scoring='roc_auc', n_jobs=-1).fit(X_train_selected, y_train).best_estimator_

# print(f"Best Model: {best_model_name}")

# # 计算SHAP值
# explainer = shap.Explainer(best_model, X_train_selected)
# shap_values = explainer(X_test_selected)

# # 绘制SHAP值的总结图
# plt.figure(figsize=(12, 8))
# shap.summary_plot(shap_values, features=pd.DataFrame(X_test_selected, columns=selected_features), show=False)
# plt.title(f'SHAP Summary Plot for {best_model_name}')
# plt.tight_layout()
# plt.show()

# # 绘制SHAP依赖图（选择最重要的特征）
# if hasattr(best_model, 'feature_importances_'):
#     feature_importances = best_model.feature_importances_
#     top_feature = selected_features[np.argmax(feature_importances)]
# else:
#     # 如果没有feature_importances_，选择SHAP值最高的特征
#     top_feature = selected_features[np.argmax(np.abs(shap_values.values).mean(axis=0))]

# plt.figure(figsize=(8, 6))
# shap.dependence_plot(top_feature, shap_values.values, pd.DataFrame(X_test_selected, columns=selected_features), show=False)
# plt.title(f'SHAP Dependence Plot for {top_feature} in {best_model_name}')
# plt.tight_layout()
# plt.show()
# 进一步进行交叉验证 ROC 曲线绘制
cv = StratifiedKFold(n_splits=5)
tprs = []
aucs = []
mean_fpr = np.linspace(0, 1, 100)

plt.figure(figsize=(10, 8))

for i, (train_idx, test_idx) in enumerate(cv.split(X_train_selected, y_train)):
    best_model.fit(X_train_selected[train_idx], y_train.iloc[train_idx])
    y_pred_proba = best_model.predict_proba(X_train_selected[test_idx])[:, 1]
    fpr, tpr, _ = roc_curve(y_train.iloc[test_idx], y_pred_proba)
    tprs.append(np.interp(mean_fpr, fpr, tpr))  # 插值
    tprs[-1][0] = 0.0
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
    plt.plot(fpr, tpr, lw=1, alpha=0.3, label='ROC fold %d (AUC = %0.4f)' % (i, roc_auc))

# 绘制对角线
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', alpha=.8)

# 绘制均值ROC曲线
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std(aucs)
plt.plot(mean_fpr, mean_tpr, color='b',
         label=r'Mean ROC (AUC = %0.4f $\pm$ %0.4f)' % (mean_auc, std_auc),
         lw=2, alpha=.8)

# 填充标准差区域
std_tpr = np.std(tprs, axis=0)
tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,
                 label=r'$\pm$ 1 std. dev.')

# 绘制图形标签
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('Internal Validation ROC Curve', fontweight='bold', fontsize=16)
plt.legend(loc="lower right", frameon=True)
plt.show()








